from django.shortcuts import render
from rest_framework import generics

#from django.http import HttpResponse

# Create your views here.

